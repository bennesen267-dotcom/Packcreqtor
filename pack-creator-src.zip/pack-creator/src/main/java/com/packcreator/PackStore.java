package com.packcreator;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.resource.Resource;
import net.minecraft.util.Identifier;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Optional;

/** Paket adı, texture yükleme ve resource pack klasörüne yazma işlemleri. */
public final class PackStore {
    public static final int PACK_FORMAT = 15; // Minecraft 1.20.1

    public static String packName = "MyPackCreatorPack";

    private PackStore() {}

    public static Path packsDir() {
        return MinecraftClient.getInstance().runDirectory.toPath().resolve("resourcepacks");
    }

    public static Path packDir() {
        return packsDir().resolve(sanitize(packName));
    }

    public static String sanitize(String s) {
        String r = s.trim().replaceAll("[^A-Za-z0-9 _.\\-]", "_");
        return r.isEmpty() ? "MyPackCreatorPack" : r;
    }

    /** Oyundaki (veya aktif paketlerdeki) mevcut dokuyu ARGB piksel dizisi olarak yükler. */
    public static LoadedTexture load(String namespace, String folder, String name) {
        Identifier id = new Identifier(namespace, "textures/" + folder + "/" + name + ".png");
        Optional<Resource> res = MinecraftClient.getInstance().getResourceManager().getResource(id);
        if (res.isPresent()) {
            try (InputStream in = res.get().getInputStream(); NativeImage img = NativeImage.read(in)) {
                int w = img.getWidth(), h = img.getHeight();
                int[] px = new int[w * h];
                for (int y = 0; y < h; y++) {
                    for (int x = 0; x < w; x++) {
                        int abgr = img.getColor(x, y);
                        int a = abgr >>> 24 & 0xFF, b = abgr >> 16 & 0xFF, g = abgr >> 8 & 0xFF, r = abgr & 0xFF;
                        px[y * w + x] = a << 24 | r << 16 | g << 8 | b;
                    }
                }
                return new LoadedTexture(w, h, px, true);
            } catch (IOException ignored) {
            }
        }
        return new LoadedTexture(16, 16, new int[16 * 16], false);
    }

    /** Dokuyu paket klasörüne yazar; pack.mcmeta yoksa oluşturur. Dönen değer: yazılan dosya. */
    public static Path save(String namespace, String folder, String name, int w, int h, int[] argb) throws IOException {
        Path root = packDir();
        Files.createDirectories(root);

        Path meta = root.resolve("pack.mcmeta");
        if (!Files.exists(meta)) {
            String json = "{\n  \"pack\": {\n    \"pack_format\": " + PACK_FORMAT
                    + ",\n    \"description\": \"Pack Creator ile oluşturuldu\"\n  }\n}\n";
            Files.writeString(meta, json, StandardCharsets.UTF_8);
        }

        Path out = root.resolve("assets").resolve(namespace).resolve("textures").resolve(folder).resolve(name + ".png");
        Files.createDirectories(out.getParent());

        try (NativeImage img = new NativeImage(NativeImage.Format.RGBA, w, h, false)) {
            for (int y = 0; y < h; y++) {
                for (int x = 0; x < w; x++) {
                    int c = argb[y * w + x];
                    int a = c >>> 24 & 0xFF, r = c >> 16 & 0xFF, g = c >> 8 & 0xFF, b = c & 0xFF;
                    img.setColor(x, y, a << 24 | b << 16 | g << 8 | r);
                }
            }
            img.writeTo(out);
        }
        return out;
    }

    public record LoadedTexture(int width, int height, int[] pixels, boolean existed) {}
}
