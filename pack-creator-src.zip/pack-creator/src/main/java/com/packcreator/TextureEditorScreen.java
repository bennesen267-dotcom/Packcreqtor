package com.packcreator;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Locale;
import java.util.function.IntConsumer;

/** Piksel editörü: kalem, silgi, doldur, damlalık, geri al, renk kaydırıcıları. */
public class TextureEditorScreen extends Screen {
    private enum Tool { PENCIL, ERASER, FILL, PICKER }

    private static final int[] PALETTE = {
            0x000000, 0xFFFFFF, 0x7F7F7F, 0x3F3F3F, 0xFF0000, 0xFF7F00, 0xFFFF00, 0x7FFF00,
            0x00FF00, 0x00FF9F, 0x00FFFF, 0x007FFF, 0x0000FF, 0x7F00FF, 0xFF00FF, 0x8B5A2B
    };

    private final Screen parent;
    private final PackCreatorScreen.Entry entry;

    private String folder;
    private int w = 16, h = 16;
    private int[] px = new int[16 * 16];
    private final Deque<int[]> undo = new ArrayDeque<>();

    private Tool tool = Tool.PENCIL;
    private int r = 255, g = 0, b = 0;
    private boolean updating;
    private String status = "";
    private int statusColor = 0xAAAAAA;

    private TextFieldWidget nameField, hexField;
    private ChannelSlider sR, sG, sB;
    private ButtonWidget folderBtn;
    private final ButtonWidget[] toolBtns = new ButtonWidget[4];

    public TextureEditorScreen(Screen parent, PackCreatorScreen.Entry entry) {
        super(Text.literal("Doku Editörü"));
        this.parent = parent;
        this.entry = entry;
        this.folder = entry.block() ? "block" : "item";
    }

    // ---------- yerleşim ----------

    private int canvasX() { return 20; }
    private int canvasY() { return 44; }

    private int canvasSize() {
        int s = Math.min(height - 110, width / 2 - 30);
        return Math.max(64, s);
    }

    private int cell() { return Math.max(1, canvasSize() / Math.max(w, h)); }

    private int rx() { return width / 2 + 10; }
    private int pw() { return width - rx() - 10; }

    @Override
    protected void init() {
        int rx = rx(), pw = pw();
        int bw = (pw - 6) / 4;
        String[] names = {"Kalem", "Silgi", "Doldur", "Damla"};
        Tool[] tools = Tool.values();
        for (int i = 0; i < 4; i++) {
            final Tool t = tools[i];
            toolBtns[i] = ButtonWidget.builder(Text.literal(names[i]), btn -> { tool = t; refreshTools(); })
                    .dimensions(rx + i * (bw + 2), 40, bw, 20).build();
            addDrawableChild(toolBtns[i]);
        }
        refreshTools();

        addDrawableChild(ButtonWidget.builder(Text.literal("Geri Al (Ctrl+Z)"), btn -> undo())
                .dimensions(rx, 64, (pw - 2) / 2, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Temizle"), btn -> { pushUndo(); px = new int[w * h]; })
                .dimensions(rx + (pw - 2) / 2 + 2, 64, (pw - 2) / 2, 20).build());

        sR = new ChannelSlider(rx, 90, pw, 16, "R", r, v -> { r = v; syncHex(); });
        sG = new ChannelSlider(rx, 108, pw, 16, "G", g, v -> { g = v; syncHex(); });
        sB = new ChannelSlider(rx, 126, pw, 16, "B", b, v -> { b = v; syncHex(); });
        addDrawableChild(sR);
        addDrawableChild(sG);
        addDrawableChild(sB);

        hexField = new TextFieldWidget(textRenderer, rx, 146, pw - 24, 16, Text.literal("Hex"));
        hexField.setMaxLength(7);
        hexField.setChangedListener(s -> {
            if (updating) return;
            String t = s.startsWith("#") ? s.substring(1) : s;
            if (t.length() == 6) {
                try { setColor(Integer.parseInt(t, 16), false); } catch (NumberFormatException ignored) {}
            }
        });
        addDrawableChild(hexField);
        syncHex();

        nameField = new TextFieldWidget(textRenderer, rx, 214, pw, 16, Text.literal("Doku adı"));
        nameField.setMaxLength(80);
        nameField.setText(entry.id().getPath());
        addDrawableChild(nameField);

        folderBtn = ButtonWidget.builder(Text.literal("Klasör: " + folder), btn -> {
            folder = folder.equals("block") ? "item" : "block";
            btn.setMessage(Text.literal("Klasör: " + folder));
            loadTexture();
        }).dimensions(rx, 236, (pw - 2) / 2, 20).build();
        addDrawableChild(folderBtn);
        addDrawableChild(ButtonWidget.builder(Text.literal("Orijinali Yükle"), btn -> loadTexture())
                .dimensions(rx + (pw - 2) / 2 + 2, 236, (pw - 2) / 2, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Kaydet"), btn -> save())
                .dimensions(rx, height - 26, (pw - 2) / 2, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Geri"), btn -> close())
                .dimensions(rx + (pw - 2) / 2 + 2, height - 26, (pw - 2) / 2, 20).build());

        if (undo.isEmpty() && isBlank()) loadTexture();
    }

    private boolean isBlank() {
        for (int p : px) if (p != 0) return false;
        return true;
    }

    private void refreshTools() {
        Tool[] tools = Tool.values();
        for (int i = 0; i < 4; i++) toolBtns[i].active = tools[i] != tool;
    }

    // ---------- renk ----------

    private void setColor(int rgb, boolean updateHex) {
        r = rgb >> 16 & 0xFF;
        g = rgb >> 8 & 0xFF;
        b = rgb & 0xFF;
        sR.setInt(r);
        sG.setInt(g);
        sB.setInt(b);
        if (updateHex) syncHex();
    }

    private void syncHex() {
        if (hexField == null) return;
        updating = true;
        hexField.setText(String.format("#%02X%02X%02X", r, g, b));
        updating = false;
    }

    private int argb() { return 0xFF000000 | r << 16 | g << 8 | b; }

    // ---------- doku işlemleri ----------

    private void loadTexture() {
        PackStore.LoadedTexture t = PackStore.load(entry.id().getNamespace(), folder, nameField.getText().trim());
        w = t.width();
        h = t.height();
        px = t.pixels().clone();
        undo.clear();
        if (t.existed()) {
            status = "Orijinal doku yüklendi (" + w + "x" + h + ")";
            statusColor = 0x55FF55;
        } else {
            status = "Bu adda doku bulunamadı, boş 16x16 tuval. Klasörü/adı değiştir.";
            statusColor = 0xFFAA00;
        }
    }

    private void pushUndo() {
        undo.push(px.clone());
        if (undo.size() > 100) undo.removeLast();
    }

    private void undo() {
        if (!undo.isEmpty()) px = undo.pop();
    }

    private static String cleanName(String s) {
        return s.trim().toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_/.\\-]", "_");
    }

    private void save() {
        String name = cleanName(nameField.getText());
        if (name.isEmpty()) {
            status = "Doku adı boş olamaz";
            statusColor = 0xFF5555;
            return;
        }
        try {
            Path p = PackStore.save(entry.id().getNamespace(), folder, name, w, h, px);
            status = "Kaydedildi: " + PackStore.sanitize(PackStore.packName) + "/.../" + p.getFileName();
            statusColor = 0x55FF55;
        } catch (IOException e) {
            status = "Kaydedilemedi: " + e.getMessage();
            statusColor = 0xFF5555;
        }
    }

    // ---------- boyama ----------

    private int pixelAt(double mx, double my) {
        int c = cell();
        int x = (int) Math.floor((mx - canvasX()) / c);
        int y = (int) Math.floor((my - canvasY()) / c);
        if (x < 0 || y < 0 || x >= w || y >= h) return -1;
        return y * w + x;
    }

    private void paint(int idx, boolean drag) {
        switch (tool) {
            case PENCIL -> px[idx] = argb();
            case ERASER -> px[idx] = 0;
            case FILL -> { if (!drag) floodFill(idx % w, idx / w, argb()); }
            case PICKER -> { if (!drag) pick(idx); }
        }
    }

    private void pick(int idx) {
        if (px[idx] >>> 24 != 0) setColor(px[idx] & 0xFFFFFF, true);
    }

    private void floodFill(int sx, int sy, int color) {
        int target = px[sy * w + sx];
        if (target == color) return;
        Deque<int[]> stack = new ArrayDeque<>();
        stack.push(new int[]{sx, sy});
        while (!stack.isEmpty()) {
            int[] p = stack.pop();
            int x = p[0], y = p[1];
            if (x < 0 || y < 0 || x >= w || y >= h || px[y * w + x] != target) continue;
            px[y * w + x] = color;
            stack.push(new int[]{x + 1, y});
            stack.push(new int[]{x - 1, y});
            stack.push(new int[]{x, y + 1});
            stack.push(new int[]{x, y - 1});
        }
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (super.mouseClicked(mx, my, button)) return true;

        int idx = pixelAt(mx, my);
        if (idx >= 0) {
            if (button == 1) { pick(idx); return true; } // sağ tık = damlalık
            if (button == 0) {
                pushUndo();
                paint(idx, false);
                return true;
            }
        }
        // palet
        int rx = rx();
        for (int i = 0; i < PALETTE.length; i++) {
            int x = rx + (i % 8) * 16, y = 170 + (i / 8) * 16;
            if (mx >= x && mx < x + 14 && my >= y && my < y + 14) {
                setColor(PALETTE[i], true);
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (super.mouseDragged(mx, my, button, dx, dy)) return true;
        if (button == 0) {
            int idx = pixelAt(mx, my);
            if (idx >= 0) {
                paint(idx, true);
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        boolean typing = getFocused() instanceof TextFieldWidget;
        if (!typing && keyCode == GLFW.GLFW_KEY_Z && Screen.hasControlDown()) {
            undo();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    // ---------- çizim ----------

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        renderBackground(ctx);

        ctx.drawItem(entry.stack(), canvasX(), 16);
        ctx.drawTextWithShadow(textRenderer, entry.id().toString() + "  (" + w + "x" + h + ")",
                canvasX() + 22, 20, 0xFFFFFF);

        int cx = canvasX(), cy = canvasY(), c = cell();
        ctx.fill(cx - 1, cy - 1, cx + c * w + 1, cy + c * h + 1, 0xFF000000);
        int gap = c >= 8 ? 1 : 0;
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int x0 = cx + x * c, y0 = cy + y * c;
                ctx.fill(x0, y0, x0 + c - gap, y0 + c - gap, ((x + y) & 1) == 0 ? 0xFF606060 : 0xFF808080);
                int p = px[y * w + x];
                if (p >>> 24 != 0) ctx.fill(x0, y0, x0 + c - gap, y0 + c - gap, p);
            }
        }
        int hov = pixelAt(mx, my);
        if (hov >= 0) {
            int x0 = cx + (hov % w) * c, y0 = cy + (hov / w) * c;
            ctx.drawBorder(x0, y0, c, c, 0xFFFFFFFF);
        }

        int rx = rx();
        ctx.fill(rx + pw() - 20, 146, rx + pw(), 162, 0xFF000000);
        ctx.fill(rx + pw() - 19, 147, rx + pw() - 1, 161, argb());
        for (int i = 0; i < PALETTE.length; i++) {
            int x = rx + (i % 8) * 16, y = 170 + (i / 8) * 16;
            ctx.fill(x - 1, y - 1, x + 15, y + 15, 0xFF000000);
            ctx.fill(x, y, x + 14, y + 14, 0xFF000000 | PALETTE[i]);
        }

        ctx.drawTextWithShadow(textRenderer, "Doku adı:", rx, 203, 0xAAAAAA);
        ctx.drawTextWithShadow(textRenderer, "İpucu: _top / _side gibi adlarla yüzleri düzenle", rx, 262, 0x888888);
        ctx.drawTextWithShadow(textRenderer, "Sağ tık = damlalık", rx, 274, 0x888888);
        if (!status.isEmpty()) {
            ctx.drawTextWithShadow(textRenderer, status, 20, height - 20, statusColor);
        }

        super.render(ctx, mx, my, delta);
    }

    @Override
    public void close() {
        client.setScreen(parent);
    }

    // ---------- kaydırıcı ----------

    private static class ChannelSlider extends SliderWidget {
        private final String label;
        private final IntConsumer callback;

        ChannelSlider(int x, int y, int width, int height, String label, int initial, IntConsumer cb) {
            super(x, y, width, height, Text.empty(), initial / 255.0);
            this.label = label;
            this.callback = cb;
            updateMessage();
        }

        void setInt(int v) {
            this.value = v / 255.0;
            updateMessage();
        }

        @Override
        protected void updateMessage() {
            setMessage(Text.literal(label + ": " + (int) Math.round(value * 255)));
        }

        @Override
        protected void applyValue() {
            callback.accept((int) Math.round(value * 255));
        }
    }
}
