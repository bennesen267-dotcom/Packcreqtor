package com.packcreator;

import net.minecraft.block.Block;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Ana menü: blok / eşya listesi, arama, paket adı. */
public class PackCreatorScreen extends Screen {
    public record Entry(Identifier id, ItemStack stack, boolean block) {}

    private enum Tab { BLOCKS, ITEMS }

    private static Tab tab = Tab.BLOCKS;
    private static String lastSearch = "";
    private static List<Entry> allBlocks;
    private static List<Entry> allItems;

    private static final int CELL = 24;

    private final List<Entry> filtered = new ArrayList<>();
    private TextFieldWidget nameField;
    private TextFieldWidget searchField;
    private ButtonWidget blocksBtn;
    private ButtonWidget itemsBtn;
    private int scrollRow = 0;
    private int cols = 1, rows = 1, gridX = 10, gridY = 64;

    public PackCreatorScreen() {
        super(Text.literal("Pack Creator"));
    }

    private static void buildLists() {
        if (allBlocks != null) return;
        allBlocks = new ArrayList<>();
        allItems = new ArrayList<>();
        var rm = MinecraftClient.getInstance().getResourceManager();

        for (Block block : Registries.BLOCK) {
            Item item = block.asItem();
            if (item == Items.AIR) continue;
            allBlocks.add(new Entry(Registries.BLOCK.getId(block), new ItemStack(item), true));
        }
        for (Item item : Registries.ITEM) {
            if (item == Items.AIR) continue;
            Identifier id = Registries.ITEM.getId(item);
            if (item instanceof BlockItem) {
                // Blok eşyalarından yalnızca kendi item dokusu olanları (kapı, tabela, fidan...) göster.
                Identifier tex = new Identifier(id.getNamespace(), "textures/item/" + id.getPath() + ".png");
                if (rm.getResource(tex).isEmpty()) continue;
            }
            allItems.add(new Entry(id, new ItemStack(item), false));
        }
    }

    @Override
    protected void init() {
        buildLists();

        nameField = new TextFieldWidget(textRenderer, 10, 22, 150, 16, Text.literal("Paket adı"));
        nameField.setMaxLength(40);
        nameField.setText(PackStore.packName);
        nameField.setChangedListener(s -> PackStore.packName = s);
        addDrawableChild(nameField);

        blocksBtn = ButtonWidget.builder(Text.literal("Bloklar"), b -> switchTab(Tab.BLOCKS))
                .dimensions(170, 20, 70, 20).build();
        itemsBtn = ButtonWidget.builder(Text.literal("Eşyalar"), b -> switchTab(Tab.ITEMS))
                .dimensions(244, 20, 70, 20).build();
        addDrawableChild(blocksBtn);
        addDrawableChild(itemsBtn);

        searchField = new TextFieldWidget(textRenderer, 10, 44, width - 20, 16, Text.literal("Ara"));
        searchField.setSuggestion(lastSearch.isEmpty() ? "Ara (ör. diamond, stone)..." : "");
        searchField.setText(lastSearch);
        searchField.setChangedListener(s -> {
            lastSearch = s;
            searchField.setSuggestion(s.isEmpty() ? "Ara (ör. diamond, stone)..." : "");
            scrollRow = 0;
            applyFilter();
        });
        addDrawableChild(searchField);

        addDrawableChild(ButtonWidget.builder(Text.literal("Paket klasörünü aç"),
                        b -> Util.getOperatingSystem().open(PackStore.packsDir().toFile()))
                .dimensions(10, height - 26, 130, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Kapat"), b -> close())
                .dimensions(width - 70, height - 26, 60, 20).build());

        gridX = 10;
        gridY = 66;
        cols = Math.max(1, (width - 20) / CELL);
        rows = Math.max(1, (height - gridY - 34) / CELL);

        refreshButtons();
        applyFilter();
    }

    private void switchTab(Tab t) {
        tab = t;
        scrollRow = 0;
        refreshButtons();
        applyFilter();
    }

    private void refreshButtons() {
        blocksBtn.active = tab != Tab.BLOCKS;
        itemsBtn.active = tab != Tab.ITEMS;
    }

    private void applyFilter() {
        filtered.clear();
        String q = lastSearch.trim().toLowerCase(Locale.ROOT);
        for (Entry e : tab == Tab.BLOCKS ? allBlocks : allItems) {
            if (q.isEmpty()
                    || e.id().toString().contains(q)
                    || e.stack().getName().getString().toLowerCase(Locale.ROOT).contains(q)) {
                filtered.add(e);
            }
        }
        clampScroll();
    }

    private int maxScroll() {
        int totalRows = (filtered.size() + cols - 1) / cols;
        return Math.max(0, totalRows - rows);
    }

    private void clampScroll() {
        scrollRow = Math.max(0, Math.min(scrollRow, maxScroll()));
    }

    private int indexAt(double mx, double my) {
        int c = (int) Math.floor((mx - gridX) / CELL);
        int r = (int) Math.floor((my - gridY) / CELL);
        if (c < 0 || c >= cols || r < 0 || r >= rows) return -1;
        int idx = (scrollRow + r) * cols + c;
        return idx < filtered.size() ? idx : -1;
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        renderBackground(ctx);
        ctx.drawTextWithShadow(textRenderer, "Pack Creator", 10, 8, 0xFFFFFF);
        ctx.drawTextWithShadow(textRenderer, filtered.size() + " sonuç", width - 80, 8, 0xAAAAAA);

        int hover = indexAt(mx, my);
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                int idx = (scrollRow + r) * cols + c;
                if (idx >= filtered.size()) break;
                int x = gridX + c * CELL, y = gridY + r * CELL;
                ctx.fill(x, y, x + CELL - 2, y + CELL - 2, idx == hover ? 0x99FFFFFF : 0x66000000);
                ctx.drawItem(filtered.get(idx).stack(), x + 3, y + 3);
            }
        }

        super.render(ctx, mx, my, delta);

        if (hover >= 0) {
            Entry e = filtered.get(hover);
            ctx.drawItemTooltip(textRenderer, e.stack(), mx, my);
        }
        if (maxScroll() > 0) {
            ctx.drawTextWithShadow(textRenderer, "Fare tekerleği ile kaydır", 150, height - 20, 0x888888);
        }
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (super.mouseClicked(mx, my, button)) return true;
        int idx = indexAt(mx, my);
        if (idx >= 0 && button == 0) {
            client.setScreen(new TextureEditorScreen(this, filtered.get(idx)));
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double amount) {
        scrollRow -= (int) Math.signum(amount) * 2;
        clampScroll();
        return true;
    }
}
