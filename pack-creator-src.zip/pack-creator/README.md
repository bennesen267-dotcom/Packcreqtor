# Pack Creator (Fabric 1.20.1)

Oyun içinden blok ve eşya dokularını düzenleyip resource pack oluşturur.

- Varsayılan tuş: **V** (Ayarlar > Kontroller > "Pack Creator" kategorisinden değiştirilebilir)
- Bloklar / Eşyalar sekmeleri, arama, piksel editörü (kalem, silgi, doldur, damlalık, geri al, RGB + hex, palet)
- Kaydedince `.minecraft/resourcepacks/<paket adı>/` altına yazılır; paketi Kaynak Paketleri ekranından etkinleştirip F3+T ile yenile.

## Derleme
Gereksinim: JDK 17+ ve internet.

    gradle build   (Gradle 8.6+; veya IntelliJ IDEA ile projeyi açıp "build" görevini çalıştır)

Çıktı: `build/libs/packcreator-1.0.0.jar` (`-sources` olmayan dosya). `mods` klasörüne at; Fabric Loader 0.15+ ve Fabric API 0.92.2+1.20.1 gerekir.
